# Human Library: Models

For details see Wiki:

- [**List of Models & Credits**](https://github.com/vladmandic/human/wiki/Models)
