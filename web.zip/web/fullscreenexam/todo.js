AWS APPRUNNER NEW URL: (staging)
=======================

Frontend  : sla-staging-entrance-exam.digivalitsolutions.com
Backend  : staging-entrance-exam-staging-api.digivalitsolutions.com

GCP CLOUDRUN NEW URL:
======================

Frontend  : sla-prod.entrance-exam.digivalitsolutions.com
Backend  : api-prod.entrance-exam.digivalitsolutions.com

https:sla-prod.entrance-exam.digivalitsolutions.com/exam-list/


dev:
===========
https://sla-entrance-exam.digivalitsolutions.com/exam-list/
emaill landing
https://sla-entrance-exam.digivalitsolutions.com/email-landing/index.html?email=kabeeraamiri@gmail.com







exam list page 

    clone api 
    finalize api 
    start exam 
    end exam 
    SEND EMAIL TEST 
    pass id while edit the question 

exam portal 
    pre populate the responces 
    submit integration 
    show end time 
    if already submitted and not started redirect 
    RESTRICTION INTEGRATIN 



    09-07-2024
    --------------
    incase of screen lock answer is not udpated - (should show error and refresh the page on anwer not saved )
    need to release a locked count incase 
    end and delete should have popup confirmation 








raghu bugs 
--------------
safari button issue - done
filter issues - filter remved - done 
expand collapse button 
export by cutt of and filter 
invalid mail format -fixed
file validation for non image formats 




done
------
time pre population issue 
icon alignment in actions area 