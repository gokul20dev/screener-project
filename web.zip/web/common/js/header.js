$(document).ready(function() {
    const headerHtml = `
        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <a class="navbar-brand" href="#">
                <img src="https://via.placeholder.com/50" width="30" height="30" class="d-inline-block align-top" alt="">
                SLA - Riyadh - Exam Portal
            </a>
        </nav>
    `;
    $(headerHtml).appendTo('body');
});
